package com.cristianfernandez.mibasedatos;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText txtUsuario,txtEmail,txtTelefono,txtFecNacimiento;
    ListView lsv ;
    int seleccionado=-1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtUsuario = findViewById(R.id.txtUsuario);
        txtTelefono = findViewById(R.id.txtTelefono);
        txtEmail = findViewById(R.id.txtEmail);
        txtFecNacimiento = findViewById(R.id.txtFechaNacimiento);
        lsv = findViewById(R.id.lsv);
        Cargar();
        // creamos un Click Listener en el List View, para cargar los datos del elemento seleccionado
        lsv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // obtenemos el view con el id "text1" y lo convertimos en tipo AppCompatTextView
                // para poder obtenes el texto que contiene
                AppCompatTextView d =(AppCompatTextView)view.findViewById(android.R.id.text1);
                int f = 0;
                // parseamos el texto de l view text1 a entero y lo guardamos en f
                 f = Integer.parseInt(d.getText()+"");
                 seleccionado=f;
                // cargamos los datos del elemento f
                cargarDatos(f);
            }
        });
    }
    /**
     * Metodo que se dispara al hacer click en el botón insertar
     * @param v
     */
    public void btnI_click(View v){
        // creamos un dao para el manejo de los usuarios en la base de datos
        DAOContactos dao = new DAOContactos(getApplicationContext());
        // checamos que todos los campos esten llenos
        if( !txtUsuario.getText().toString().isEmpty() && !txtTelefono.getText().toString().isEmpty() &&
                !txtEmail.getText().toString().isEmpty() && !txtFecNacimiento.getText().toString().isEmpty()){
            // campos llenos!
            // Agregamos un nuevo usuario con los datos introducidos y obtenemos el resultado
            long result = dao.add(
                    new Contacto(0, txtUsuario.getText().toString(), txtTelefono.getText().toString(), txtEmail.getText().toString(),txtFecNacimiento.getText().toString())
            );
            // comprobamos que el usuario se registró en la base de datos
            if (result>0){
                Toast.makeText(this, "Datos Guardados",
                        Toast.LENGTH_LONG).show();
                Cargar();
                txtUsuario.setText("");
                txtTelefono.setText("");
                txtEmail.setText("");
                txtFecNacimiento.setText("");
            }
        }else{
            // Faltan datos por llenar!
            Toast.makeText(this, "Llena todos los campos",Toast.LENGTH_LONG).show();
        }
    }
    /**
     * Metodo que llena los campos con los datos correspondientes a un usuario en particular
      * @param id - id del usuario
     */
    public void cargarDatos(int id){
        // creamos un objeto para el acceso a la base de datos
        DAOContactos dao = new DAOContactos(getApplicationContext());
        // buscamos al usuario con el id que se recibió como parametro
        Contacto con = dao.buscar(id);
        // cargamos sus datos
                txtUsuario.setText(con.getNombre());
                txtTelefono.setText(con.getTelefono());
                txtEmail.setText(con.getEmail());
                txtFecNacimiento.setText(con.getFechaNacimiento());

    }
    /**
     * Metodo que se encarga de crear los views para cada registro en la base de datos para
     * posteriorment agregarlos al list view
     */
    public void Cargar(){
            // creamos un objeto para el acceso a la informacion en la base de datos
            DAOContactos dao = new DAOContactos(this);
            //accedemos a los usuarios
            Cursor c =  dao.getAllC();
        //agregamos los usuarios al listview usando un adaptador generico
      if(c.moveToFirst()){
          SimpleCursorAdapter adp = new SimpleCursorAdapter(
                  this, android.R.layout.simple_list_item_2 ,
                  c , MiBD.COLUMNS_USUARIOS,
                  new int[]{android.R.id.text1, android.R.id.text2, android.R.id.textAssist},
                  SimpleCursorAdapter.NO_SELECTION
          );
        // agregamos el adaptdor con los usuarios al list view
          lsv.setAdapter(adp);
      }else{
          lsv.setAdapter(null);
      }
    }
    /**
     * Metodo que se dispara al dar click en el boton Eliminar
     * @param view
     */
    public void btnEliminar_click(View view) {
        // creamos un objeto para el acceso a la informacion en la base de datos
        DAOContactos ado = new DAOContactos(getApplicationContext());
        // verificamos si se a seleccionado un usuario
        if(seleccionado!=-1){
            //usuario seleccionado
            // intentamos borrarlo
              if (ado.getBorrar(new Contacto(seleccionado))==1){
                  txtUsuario.setText("");
                  Toast.makeText(this, "Registro eliminado",Toast.LENGTH_LONG).show();
                  Cargar();
                  txtUsuario.setText("");
                  txtTelefono.setText("");
                  txtEmail.setText("");
                  txtFecNacimiento.setText("");
              }else{
                  Toast.makeText(this, "Error al borrar",Toast.LENGTH_LONG).show();
              }
        }else{
            //usuario no seleccionado
            Toast.makeText(this, "Selecciona un usuario para borrar",Toast.LENGTH_LONG).show();
        }
    }
    /**
     * Metodo que se dispara al hacer click en el botón editar
     * @param v
     */
    public void btnEditar_click(View v){
        // creamos un dao para el manejo de los usuarios en la base de datos
        DAOContactos dao = new DAOContactos(getApplicationContext());
        if(seleccionado!=-1) {
        // checamos que todos los campos esten llenos
        if( !txtUsuario.getText().toString().isEmpty() && !txtTelefono.getText().toString().isEmpty() &&
                !txtEmail.getText().toString().isEmpty() && !txtFecNacimiento.getText().toString().isEmpty()){
            // campos llenos!
                long result = dao.update(
                        new Contacto(seleccionado, txtUsuario.getText().toString(), txtTelefono.getText().toString(), txtEmail.getText().toString(), txtFecNacimiento.getText().toString())
                );
                // comprobamos que el usuario se editó en la base de datos
                if (result > 0) {
                    Toast.makeText(this, "usuario editado",
                            Toast.LENGTH_LONG).show();
                    Cargar();
                    txtUsuario.setText("");
                    txtTelefono.setText("");
                    txtEmail.setText("");
                    txtFecNacimiento.setText("");
                }else{
                    Toast.makeText(this, "no se editó el elemento con el id: "+seleccionado,
                            Toast.LENGTH_LONG).show();
                }
        }else{
            // Faltan datos por llenar!
            Toast.makeText(this, "Llena todos los campos",Toast.LENGTH_LONG).show();
        }
        }else{
            Toast.makeText(this, "Selecciona un usuario para editar",Toast.LENGTH_LONG).show();
        }
    }
    public void Buscar_click (View v) {
        Contacto u=new Contacto(0,"","","","");
        DAOContactos dao = new DAOContactos(this);
        List<Contacto> lst =  dao.search(u, txtUsuario.getText().toString());
        for (Contacto item: lst
        ) {
            Log.d("CONTACTO: " ,  String.valueOf( item.getId()));
            Log.d("CONTACTO: " , item.getNombre());
        }
        Cursor c =  dao.getAllC1(u,txtUsuario.getText().toString());
        SimpleCursorAdapter adp = new SimpleCursorAdapter(
                this, android.R.layout.simple_list_item_2 ,
                c , MiBD.COLUMNS_USUARIOS,
                new int[]{android.R.id.text1, android.R.id.text2},
                SimpleCursorAdapter.NO_SELECTION
        );
        lsv.setAdapter(adp);
    }
}

