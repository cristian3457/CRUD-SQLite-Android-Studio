package com.cristianfernandez.mibasedatos;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.DateFormat;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DAOContactos {

    private SQLiteDatabase _ad ;

    public DAOContactos(Context ctx) {
          _ad =
                  new MiBD(ctx).getWritableDatabase();
    }

    public long add(Contacto u)
    {

        ContentValues cv = new ContentValues();

        cv.put(MiBD.COLUMNS_USUARIOS[1], u.getNombre() );
        cv.put(MiBD.COLUMNS_USUARIOS[2], u.getTelefono() );
        cv.put(MiBD.COLUMNS_USUARIOS[3], u.getEmail());
        cv.put(MiBD.COLUMNS_USUARIOS[4], u.getFechaNacimiento() );
        long result =_ad.insert(MiBD.TABLES_DB[0],null,cv);
        //_ad.close();
        return result;

    }

    public long   update (Contacto u){
        ContentValues cv = new ContentValues();
        cv.put(MiBD.COLUMNS_USUARIOS[1], u.getNombre() );
        cv.put(MiBD.COLUMNS_USUARIOS[2], u.getTelefono() );
        cv.put(MiBD.COLUMNS_USUARIOS[3], u.getEmail());
        cv.put(MiBD.COLUMNS_USUARIOS[4], u.getFechaNacimiento() );

        return _ad.update(MiBD.TABLES_DB[0],
                cv,
                "_id=?",
                new String[]{String.valueOf( u.getId())}
                );
        //_ad.close();

    }

    public List<Contacto> getAll(){
        List <Contacto> lst = new ArrayList<Contacto>();
         Cursor c = _ad.query(
                MiBD.TABLES_DB[0],
                MiBD.COLUMNS_USUARIOS,
                null, null,null,null,null
        );

         while(c.moveToNext()){

             lst.add(
               new Contacto(c.getInt(0), c.getString(1),
                       c.getString(2), c.getString(3),
                       c.getString(4))
             );

         }

        //_ad.close();
        return lst;
    }

    public Cursor getAllC(){
        Cursor c = _ad.query(
                MiBD.TABLES_DB[0],
                MiBD.COLUMNS_USUARIOS,
                null, null,null,null,null
        );
        return c;
    }
    public Cursor getAllC1(Contacto user, String nombre){
        Cursor c = _ad.rawQuery("select * from usuarios where nombre='"+nombre+"'", null);
        return c;
    }

  public Contacto buscar(int id){
       List<Contacto> todos = getAll();
      for (Contacto n:todos) {
          if (n.id == id){
              return n;
          }
      }
       return new Contacto(0,""+id,"","","");
    }

    public List<Contacto > search (Contacto user, String nombre) {
        List <Contacto> lst = new ArrayList<Contacto>();

        Cursor c = _ad.rawQuery("select * from usuarios where nombre='"+nombre+"'", null);

        while(c.moveToNext()){

            lst.add(
                    new Contacto(c.getInt(0), c.getString(1),
                            c.getString(2), c.getString(3),
                            c.getString(4) )
            );

        }
        return lst;
    }

   public int getBorrar(Contacto u){

        return _ad.delete(MiBD.TABLES_DB[0],"_id='"+u.getId()+"'",null);
   }
}

